# Email Marketing Campaign – Data Science Case Study

## Author
**Vishakha Shishodia**

## Objective
Analyze an email campaign to:
- Measure open and click-through rates.
- Build a machine learning model to predict email link clicks.
- Segment users based on behavior.
- Recommend strategies for improving future campaigns.

## Files
- `email_table.csv`: Email metadata.
- `email_opened_table.csv`: IDs of opened emails.
- `link_clicked_table.csv`: IDs of clicked emails.
- `notebook.ipynb`: Jupyter notebook for data analysis and model building.
- `Email_Marketing_Case_Study_Report_Vishakha.pdf`: Final written report.
- `requirements.txt`: List of Python dependencies.

## How to Run
1. Open `notebook.ipynb` in Jupyter Notebook.
2. Run all cells to load data, preprocess, train the model, and evaluate.
3. View the final report in `Email_Marketing_Case_Study_Report_Vishakha.pdf`.

## Output
- Open rate and CTR metrics.
- Trained Random Forest model.
- Classification metrics.
- User behavior insights.
